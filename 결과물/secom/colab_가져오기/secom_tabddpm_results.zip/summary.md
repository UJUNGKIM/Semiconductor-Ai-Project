# SECOM 공식 TabDDPM Colab 결과

- 실행 모드: paper
- GPU: Tesla T4
- 학습 step: 30000
- 학습 시간: 5.4분
- validation 선택: CatBoost / TabDDPM_1.00
- validation PR-AUC: 0.1512
- validation F2: 0.3731
- 임계값은 validation F2로 선택
- test는 모델·전략·임계값 선택에 사용하지 않음
